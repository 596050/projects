# nlp-webinar
Configuration commands and sample data used in NLP Webinar

This is the configuraiton files and sample data that was used for the Elastic webinar called [Introduction to NLP models and vector search: Part II](https://www.elastic.co/virtual-events/introduction-to-nlp-models-and-vector-search-part-2)

As part of that webinar we featured a proof of concept [search app using Flask](https://github.com/radoondas/flask-elastic-nlp)

