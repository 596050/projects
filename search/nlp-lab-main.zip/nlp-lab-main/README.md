# nlp-lab
Examples and data sets used in elasticsearch ml nlp lab tutorial
