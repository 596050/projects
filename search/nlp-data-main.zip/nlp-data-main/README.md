# nlp-data
data sets and command reference for NLP blog
