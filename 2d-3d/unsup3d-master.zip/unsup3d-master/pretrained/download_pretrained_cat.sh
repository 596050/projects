echo "----------------------- downloading pretrained model on cat dataset -----------------------"
curl -o pretrained_cat.zip "https://www.robots.ox.ac.uk/~vgg/research/unsup3d/data/pretrained_cat.zip" && unzip pretrained_cat.zip
