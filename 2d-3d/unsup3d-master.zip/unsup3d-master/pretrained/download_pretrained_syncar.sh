echo "----------------------- downloading pretrained model on synthetic car dataset -----------------------"
curl -o pretrained_syncar.zip "https://www.robots.ox.ac.uk/~vgg/research/unsup3d/data/pretrained_syncar.zip" && unzip pretrained_syncar.zip
