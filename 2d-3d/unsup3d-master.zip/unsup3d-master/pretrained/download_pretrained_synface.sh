echo "----------------------- downloading pretrained model on synthetic face dataset -----------------------"
curl -o pretrained_synface.zip "https://www.robots.ox.ac.uk/~vgg/research/unsup3d/data/pretrained_synface.zip" && unzip pretrained_synface.zip
