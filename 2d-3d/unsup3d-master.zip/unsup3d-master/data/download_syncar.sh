echo "----------------------- downloading synthetic car dataset -----------------------"
curl -o syncar.zip "https://www.robots.ox.ac.uk/~vgg/research/unsup3d/data/syncar.zip" && unzip syncar.zip
