echo "----------------------- downloading synthetic face dataset -----------------------"
curl -o synface.zip "https://www.robots.ox.ac.uk/~vgg/research/unsup3d/data/synface.zip" && unzip synface.zip
