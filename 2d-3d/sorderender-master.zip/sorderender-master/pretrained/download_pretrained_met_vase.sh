echo "----------------------- downloading pretrained model on synthetic vases -----------------------"
curl -o syn_vase_pretrained.zip "https://www.robots.ox.ac.uk/~vgg/research/sorderender/data/syn_vase_pretrained.zip" && unzip syn_vase_pretrained.zip
