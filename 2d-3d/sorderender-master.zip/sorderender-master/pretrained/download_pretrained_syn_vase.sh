echo "----------------------- downloading pretrained model on met vases -----------------------"
curl -o met_vase_pretrained.zip "https://www.robots.ox.ac.uk/~vgg/research/sorderender/data/met_vase_pretrained.zip" && unzip met_vase_pretrained.zip
