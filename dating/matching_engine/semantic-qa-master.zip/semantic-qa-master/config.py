# Universal Sentence Encoder Tf Hub url
MODEL_URL = "https://tfhub.dev/google/universal-sentence-encoder/4"

# Elasticsearch ip and port
ELASTIC_IP = "localhost"
ELASTIC_PORT = 9200

# Min score for the match
SEARCH_THRESH = 1.2
