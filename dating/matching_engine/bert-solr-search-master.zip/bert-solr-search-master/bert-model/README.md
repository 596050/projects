Put your BERT model here unarchived .
Then review / update the path to the model in [start_bert_server.sh](https://github.com/DmitryKey/bert-solr-search/blob/master/start_bert_server.sh) script.