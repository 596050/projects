Data directory
===

`dbpedia/` should contain the input data file. Experiments were done with long_abstracts_en.ttl.bz2 of DBPedia collection.

`gsp_apu/` contains precomputed vectors and index files for the data in `dbpedia/`

`screencasts/` contains streamlit screencasts