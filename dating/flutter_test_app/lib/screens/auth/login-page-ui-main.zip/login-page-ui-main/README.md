# mobile-login-page-ui

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Here is the design link of this](https://dribbble.com/shots/17505669-UI-Design-Login-Page-Using-Flutter)

![](https://github.com/mahendraputra21/login-page-ui/blob/main/Login.png)

<img width="252" alt="login" src="https://github.com/mahendraputra21/login-page-ui/blob/main/Login.jpeg">

<img width="252" alt="login" src="https://github.com/mahendraputra21/login-page-ui/blob/main/Login2.jpeg">


- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)
- [Reference](https://www.youtube.com/watch?v=HWb6v8VcNnQ&ab_channel=EricoDarmawanHandoyo)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
