<h2 align = "center"> Login screen tinder<br><br></h2>
<p align ="center"> Um clone da tela de login do tinder para treinar o que aprendi até agora<br>(Apenas o front end)</p>


- Utilizando apenas os widgets básicos do Flutter(Stack, Row, Containers, ImageIcon...)



  
  

![image](https://user-images.githubusercontent.com/73318684/153321402-6af4b9ce-b36f-4bfd-9b4d-f2357fb82ba3.png)  


<h3>To-do: Fazer melhorias no código, utilizar algum package externo e trazer mais telas</h3>
