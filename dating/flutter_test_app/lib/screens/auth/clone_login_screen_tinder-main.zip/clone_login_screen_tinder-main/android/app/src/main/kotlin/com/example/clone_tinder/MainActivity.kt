package com.example.clone_tinder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
